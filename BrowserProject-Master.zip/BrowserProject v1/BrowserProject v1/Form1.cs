﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrowserProject_v1
{
    public partial class Form1 : Form
    {
        string i;
        void repeat()
        {
            i = Convert.ToString(webBrowser1.Url);
            tb.Text = i;
            if (Convert.ToString(webBrowser1.Url) != i)
            {
                tb.Text = Convert.ToString(webBrowser1.Url);
            }

        }
        public Form1()
        {
            InitializeComponent();
            webBrowser1.ScriptErrorsSuppressed=true;
            repeat();

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            repeat();
            tb.Text = Convert.ToString("https://duckduckgo.com/");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
            repeat();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
            repeat();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
            repeat();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            repeat();
            webBrowser1.Navigate(Convert.ToString(tb.Text), null, null, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            repeat();
            webBrowser1.Navigate("https://duckduckgo.com/",null,null, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36");

        }

        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This Browser was created by Michael Makris\n\nBrowser Project is a light-weight browser that does not keep any data of any kind","About",MessageBoxButtons.OK,MessageBoxIcon.Information);
        }


    }
}
